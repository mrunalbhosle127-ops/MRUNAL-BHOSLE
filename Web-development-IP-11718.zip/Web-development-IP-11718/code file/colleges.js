const colleges = [

{
    name: "Pune Institute of Technology",
    city: "Pune",
    courses: "B.Tech, BCA, MBA",
    fees: "₹1,20,000 / year",
    rating: "4.7 ⭐",
    contact: "+91 20 4567 8901",
    image: "https://images.unsplash.com/photo-1562774053-701939374585?w=800"
},



{
    name: "National College of Engineering",
    city: "Hyderabad",
    courses: "B.Tech, M.Tech",
    fees: "₹1,45,000 / year",
    rating: "4.8 ⭐",
    contact: "+91 40 3344 8899",
    image: "https://images.unsplash.com/photo-1607237138185-eedd9c632b0b?w=800"
},

{
    name: "Sunrise University",
    city: "Jaipur",
    courses: "BBA, MBA, Commerce",
    fees: "₹90,000 / year",
    rating: "4.5 ⭐",
    contact: "+91 141 456 7788",
    image: "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=800"
},

{
    name: "Royal Institute of Technology",
    city: "Delhi",
    courses: "BCA, B.Tech, MCA",
    fees: "₹1,10,000 / year",
    rating: "4.4 ⭐",
    contact: "+91 11 2233 8899",
    image: "https://images.unsplash.com/photo-1498243691581-b145c3f54a5a?w=800"
},

{
    name: "Future Skills University",
    city: "Mumbai",
    courses: "BCA, MBA, Data Science",
    fees: "₹1,35,000 / year",
    rating: "4.9 ⭐",
    contact: "+91 22 3344 5566",
    image: "https://images.unsplash.com/photo-1564981797816-1043664bf78d?w=800"
},

{
    name: "Oxford College of Management",
    city: "Chennai",
    courses: "MBA, BBA, Finance",
    fees: "₹1,00,000 / year",
    rating: "4.3 ⭐",
    contact: "+91 44 5566 7788",
    image: "https://images.unsplash.com/photo-1519452575417-564c1401ecc0?w=800"
},

{
    name: "City Science College",
    city: "Nagpur",
    courses: "B.Sc, BCA, MCA",
    fees: "₹80,000 / year",
    rating: "4.6 ⭐",
    contact: "+91 712 445 8899",
    image: "https://images.unsplash.com/photo-1588072432836-e10032774350?w=800"
}

];