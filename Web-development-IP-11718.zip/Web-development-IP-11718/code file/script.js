const container = document.getElementById("collegeContainer");
const modal = document.getElementById("modal");
const modalBody = document.getElementById("modalBody");
const closeModal = document.getElementById("closeModal");
const topBtn = document.getElementById("topBtn");

// Display Colleges
function displayColleges(data) {

    container.innerHTML = "";

    if(data.length === 0){
        container.innerHTML = "<h2 style='text-align:center;width:100%;'>No Colleges Found</h2>";
        return;
    }

    data.forEach(college => {

        container.innerHTML += `

        <div class="card">

            <img src="${college.image}" alt="${college.name}">

            <div class="card-content">

                <h3>${college.name}</h3>

                <p><strong>📍 City:</strong> ${college.city}</p>

                <p><strong>🎓 Courses:</strong> ${college.courses}</p>

                <p><strong>⭐ Rating:</strong> ${college.rating}</p>

                <button onclick="showDetails('${college.name}','${college.city}','${college.courses}','${college.fees}','${college.rating}','${college.contact}')">

                    Explore

                </button>

            </div>

        </div>

        `;

    });

}

displayColleges(colleges);

// Search
function searchCollege(){

    const text = document
        .getElementById("searchInput")
        .value
        .toLowerCase();

    const filtered = colleges.filter(college =>

        college.name.toLowerCase().includes(text) ||

        college.city.toLowerCase().includes(text) ||

        college.courses.toLowerCase().includes(text)

    );

    displayColleges(filtered);

}

document
.getElementById("searchInput")
.addEventListener("keyup",searchCollege);

// Modal

function showDetails(name,city,courses,fees,rating,contact){

    modalBody.innerHTML = `

        <h2>${name}</h2>

        <br>

        <p><strong>📍 City:</strong> ${city}</p>

        <p><strong>🎓 Courses:</strong> ${courses}</p>

        <p><strong>💰 Fees:</strong> ${fees}</p>

        <p><strong>⭐ Rating:</strong> ${rating}</p>

        <p><strong>☎ Contact:</strong> ${contact}</p>

    `;

    modal.style.display="block";

}

closeModal.onclick=function(){

    modal.style.display="none";

}

window.onclick=function(e){

    if(e.target==modal){

        modal.style.display="none";

    }

}

// Scroll Button

window.onscroll=function(){

    if(document.documentElement.scrollTop>250){

        topBtn.style.display="block";

    }else{

        topBtn.style.display="none";

    }

}

topBtn.onclick=function(){

    window.scrollTo({

        top:0,

        behavior:"smooth"

    });

}

// Contact Form

const form=document.querySelector(".contact-form");

form.addEventListener("submit",function(e){

    e.preventDefault();

    alert("Thank you! Your message has been submitted.");

    form.reset();

});